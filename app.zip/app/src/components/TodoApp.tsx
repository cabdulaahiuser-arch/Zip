import { useTodos } from '@/hooks/useTodos'
import TodoForm from '@/components/TodoForm'
import TodoItem from '@/components/TodoItem'
import TodoFilters from '@/components/TodoFilters'
import TodoStats from '@/components/TodoStats'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { ListTodo, Trash2 } from 'lucide-react'

export default function TodoApp() {
  const {
    filteredTodos,
    filter,
    setFilter,
    sortBy,
    setSortBy,
    searchQuery,
    setSearchQuery,
    categoryFilter,
    setCategoryFilter,
    categories,
    addTodo,
    toggleTodo,
    updateTodo,
    deleteTodo,
    clearCompleted,
    stats,
  } = useTodos()

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="p-3 bg-primary/10 rounded-xl">
          <ListTodo className="h-6 w-6 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">To-Do List</h1>
          <p className="text-sm text-muted-foreground">Stay organized and get things done</p>
        </div>
      </div>

      {/* Stats */}
      <TodoStats {...stats} />

      {/* Add Todo Form */}
      <div className="bg-card border rounded-xl p-4">
        <TodoForm onAdd={addTodo} existingCategories={categories} />
      </div>

      {/* Filters */}
      <TodoFilters
        filter={filter}
        setFilter={setFilter}
        sortBy={sortBy}
        setSortBy={setSortBy}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        categoryFilter={categoryFilter}
        setCategoryFilter={setCategoryFilter}
        categories={categories}
        activeCount={stats.active}
        completedCount={stats.completed}
        totalCount={stats.total}
      />

      {/* Todo List */}
      <div className="space-y-2">
        {filteredTodos.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <ListTodo className="h-12 w-12 mx-auto mb-3 opacity-30" />
            <p className="text-lg font-medium">No tasks found</p>
            <p className="text-sm">
              {searchQuery
                ? 'Try a different search term'
                : filter === 'completed'
                ? 'Complete some tasks to see them here'
                : 'Add a new task to get started'}
            </p>
          </div>
        ) : (
          <ScrollArea className="h-auto max-h-[600px]">
            <div className="space-y-2 pr-3">
              {filteredTodos.map(todo => (
                <TodoItem
                  key={todo.id}
                  todo={todo}
                  onToggle={toggleTodo}
                  onUpdate={updateTodo}
                  onDelete={deleteTodo}
                  existingCategories={categories}
                />
              ))}
            </div>
          </ScrollArea>
        )}
      </div>

      {/* Clear Completed */}
      {stats.completed > 0 && (
        <div className="flex justify-center">
          <Button
            variant="outline"
            size="sm"
            onClick={clearCompleted}
            className="text-destructive hover:text-destructive"
          >
            <Trash2 className="h-4 w-4 mr-1" />
            Clear {stats.completed} completed task{stats.completed !== 1 ? 's' : ''}
          </Button>
        </div>
      )}
    </div>
  )
}
