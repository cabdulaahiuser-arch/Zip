package com.gesturememe.app;

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark;

import java.util.List;

/** Bundles one hand's landmarks, finger states, and left/right side. */
public class Hand {
    public final List<NormalizedLandmark> landmarks;
    public final int[] fingerState;
    public final boolean isLeft;

    public Hand(List<NormalizedLandmark> landmarks, int[] fingerState, boolean isLeft) {
        this.landmarks = landmarks;
        this.fingerState = fingerState;
        this.isLeft = isLeft;
    }

    public String sideLabel() {
        return isLeft ? "I" : "D";
    }
}
