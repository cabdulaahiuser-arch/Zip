package com.gesturememe.app;

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Port of the Python Cal class. Collects N frames of a neutral face to
 * establish personalized thresholds for brow-raise, tongue-out, etc.,
 * instead of using fixed thresholds that vary per-person.
 */
public class Calibrator {

    private static final int N = 45;

    private final Map<String, List<Double>> buf = new HashMap<>();
    private final Map<String, Double> thr = new HashMap<>();
    private boolean done = false;

    public Calibrator() {
        for (String key : new String[]{"ci", "cd", "cen", "lap", "llb", "bi_y", "bd_y", "gap"}) {
            buf.put(key, new ArrayList<>());
        }
        // Sensible fallback defaults, overwritten once calibration completes.
        thr.put("ci", 0.180);
        thr.put("cd", 0.180);
        thr.put("cen_lo", 0.185);
        thr.put("lap", 0.055);
        thr.put("llb", 0.145);
        thr.put("bi_y_lo", 0.30);
        thr.put("bd_y_lo", 0.30);
        thr.put("gap_lo", 0.10);
    }

    public boolean isDone() {
        return done;
    }

    public double progress() {
        return Math.min(buf.get("ci").size() / (double) N, 1.0);
    }

    public double threshold(String key) {
        Double v = thr.get(key);
        return v == null ? 0.0 : v;
    }

    /** Feed one frame of face landmarks during the calibration phase. */
    public void feed(List<NormalizedLandmark> lm) {
        if (done) {
            return;
        }
        double e = GeometryUtils.faceScale(lm);
        buf.get("ci").add(GeometryUtils.distance(lm.get(52), lm.get(159)) / e);
        buf.get("cd").add(GeometryUtils.distance(lm.get(282), lm.get(386)) / e);
        buf.get("cen").add(GeometryUtils.distance(lm.get(55), lm.get(285)) / e);
        buf.get("lap").add(GeometryUtils.distance(lm.get(13), lm.get(14)) / e);
        buf.get("llb").add(GeometryUtils.distance(lm.get(17), lm.get(152)) / e);
        buf.get("bi_y").add((double) (lm.get(55).y() - lm.get(9).y()));
        buf.get("bd_y").add((double) (lm.get(285).y() - lm.get(9).y()));
        buf.get("gap").add((double) Math.abs(lm.get(55).x() - lm.get(285).x()));

        if (buf.get("ci").size() >= N) {
            calculate();
        }
    }

    private double median(String key) {
        List<Double> vals = new ArrayList<>(buf.get(key));
        Collections.sort(vals);
        int mid = vals.size() / 2;
        if (vals.size() % 2 == 0) {
            return (vals.get(mid - 1) + vals.get(mid)) / 2.0;
        }
        return vals.get(mid);
    }

    private double std(String key) {
        List<Double> vals = buf.get(key);
        double mean = 0;
        for (double v : vals) mean += v;
        mean /= vals.size();
        double sumSq = 0;
        for (double v : vals) sumSq += (v - mean) * (v - mean);
        return Math.sqrt(sumSq / vals.size());
    }

    private double marginCeja(String key) {
        return Math.max(1.5 * std(key), 0.015);
    }

    private double marginBoca(String key, double min) {
        return Math.max(3 * std(key), min);
    }

    private void calculate() {
        thr.put("ci", median("ci") + marginCeja("ci"));
        thr.put("cd", median("cd") + marginCeja("cd"));
        thr.put("cen_lo", median("cen") - marginCeja("cen"));
        thr.put("lap", median("lap") + marginBoca("lap", 0.032));
        thr.put("llb", median("llb") - marginBoca("llb", 0.018));
        thr.put("bi_y_lo", median("bi_y") + marginCeja("bi_y"));
        thr.put("bd_y_lo", median("bd_y") + marginCeja("bd_y"));
        thr.put("gap_lo", median("gap") - marginCeja("gap"));
        done = true;
    }
}
