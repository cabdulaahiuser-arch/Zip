package com.gesturememe.app;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;

/**
 * Port of the Python main loop's `deque(maxlen=10)` + `Counter` majority-vote
 * smoothing: keeps the last N detections and only switches the displayed
 * meme once one gesture wins at least MIN_VOTES of the buffer.
 */
public class VoteBuffer {

    private final int maxLen;
    private final int minVotes;
    private final Deque<String> buffer = new ArrayDeque<>();

    public VoteBuffer(int maxLen, int minVotes) {
        this.maxLen = maxLen;
        this.minVotes = minVotes;
    }

    /**
     * Adds a new detection (nullable) and returns the current stable
     * winner, or null if no gesture yet meets the vote threshold.
     */
    public String addAndGetStable(String detection, String currentStable) {
        buffer.addLast(detection);
        if (buffer.size() > maxLen) {
            buffer.removeFirst();
        }

        Map<String, Integer> counts = new HashMap<>();
        String top = null;
        int topCount = 0;
        for (String item : buffer) {
            int c = counts.merge(item, 1, Integer::sum);
            if (c > topCount) {
                topCount = c;
                top = item;
            }
        }

        if (topCount >= minVotes) {
            return top;
        }
        return currentStable;
    }
}
