package com.gesturememe.app;

/** Static landmark-index paths used for the minimal mesh overlay, ported verbatim from Python. */
public final class LandmarkPaths {

    private LandmarkPaths() {
    }

    public static final int[] FACE_OVAL = {
            10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288,
            397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136,
            172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109, 10
    };

    public static final int[] EYE_L = {
            33, 246, 161, 160, 159, 158, 157, 173, 133, 155, 154, 153, 145, 144, 163, 7, 33
    };

    public static final int[] EYE_R = {
            362, 398, 384, 385, 386, 387, 388, 466, 263, 249, 390, 373, 374, 380, 381, 382, 362
    };

    public static final int[] BROW_L = {70, 63, 105, 66, 107, 55, 65, 52, 53, 46};

    public static final int[] BROW_R = {300, 293, 334, 296, 336, 285, 295, 282, 283, 276};

    public static final int[] LIPS_OUT = {
            61, 146, 91, 181, 84, 17, 314, 405, 321, 375, 291, 409, 270, 269, 267, 0, 37, 39, 40, 185, 61
    };

    public static final int[] LIPS_IN = {
            78, 95, 88, 178, 87, 14, 317, 402, 318, 324, 308, 415, 310, 311, 312, 13, 82, 81, 80, 191, 78
    };

    public static final int[] NOSE = {168, 6, 197, 195, 5, 4, 1, 19, 94, 2};

    /** Pairs of landmark indices to connect for the hand skeleton. */
    public static final int[][] HAND_CONNECTIONS = {
            {0, 1}, {1, 2}, {2, 3}, {3, 4},
            {0, 5}, {5, 6}, {6, 7}, {7, 8},
            {0, 9}, {9, 10}, {10, 11}, {11, 12},
            {0, 13}, {13, 14}, {14, 15}, {15, 16},
            {0, 17}, {17, 18}, {18, 19}, {19, 20},
            {5, 9}, {9, 13}, {13, 17}
    };
}
