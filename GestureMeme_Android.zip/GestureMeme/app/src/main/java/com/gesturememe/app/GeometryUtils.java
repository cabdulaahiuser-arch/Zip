package com.gesturememe.app;

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark;

import java.util.List;

/**
 * Small geometry helpers, ported 1:1 from the Python script's
 * d(), esc(), px() and dedos_estado() free functions.
 */
public final class GeometryUtils {

    private GeometryUtils() {
    }

    /** Euclidean distance between two normalized landmarks (matches Python's d()). */
    public static double distance(NormalizedLandmark a, NormalizedLandmark b) {
        double dx = a.x() - b.x();
        double dy = a.y() - b.y();
        double dz = a.z() - b.z();
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /**
     * Face scale reference: distance between chin (152) and forehead (10),
     * used to normalize every other measurement. Matches Python's esc().
     */
    public static double faceScale(List<NormalizedLandmark> lm) {
        return distance(lm.get(152), lm.get(10)) + 1e-6;
    }

    /** Convert a normalized landmark to pixel coordinates in a W x H frame. */
    public static int[] toPixel(NormalizedLandmark pt, int w, int h) {
        return new int[]{(int) (pt.x() * w), (int) (pt.y() * h)};
    }

    /**
     * Finger extended/folded state for one hand, matching Python's dedos_estado().
     * Index 0 = thumb, 1..4 = index/middle/ring/pinky.
     * Result is 1 (extended) or 0 (folded) per finger.
     */
    public static int[] fingerState(List<NormalizedLandmark> lm, boolean isLeft) {
        int[] tip = {8, 12, 16, 20};
        int[] midJoint = {6, 10, 14, 18};

        int[] out = new int[5];
        boolean thumbExtended = isLeft
                ? lm.get(4).x() > lm.get(3).x()
                : lm.get(4).x() < lm.get(3).x();
        out[0] = thumbExtended ? 1 : 0;

        for (int i = 0; i < 4; i++) {
            out[i + 1] = (lm.get(tip[i]).y() < lm.get(midJoint[i]).y()) ? 1 : 0;
        }
        return out;
    }
}
