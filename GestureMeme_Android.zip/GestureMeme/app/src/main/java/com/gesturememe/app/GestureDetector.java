package com.gesturememe.app;

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark;

import java.util.Arrays;
import java.util.List;

/**
 * Port of the Python script's det_lengua / det_ceja / det_cristiano /
 * det_rata / det_sonic / det_cara functions. Each mirrors the original
 * logic and thresholds exactly.
 */
public final class GestureDetector {

    private GestureDetector() {
    }

    /** Tongue out: mouth open + lower lip drop + tongue tip below inner lip. */
    public static boolean detectTongue(List<NormalizedLandmark> lm, Calibrator cal) {
        double e = GeometryUtils.faceScale(lm);
        boolean bocaAbierta = GeometryUtils.distance(lm.get(13), lm.get(14)) / e > cal.threshold("lap");
        boolean lenguaBaja = GeometryUtils.distance(lm.get(17), lm.get(152)) / e < cal.threshold("llb");
        boolean puntaFuera = lm.get(17).y() > lm.get(14).y() + 0.012;
        return bocaAbierta && lenguaBaja && puntaFuera;
    }

    /** Eyebrows raised or furrowed. */
    public static boolean detectBrow(List<NormalizedLandmark> lm, Calibrator cal) {
        double e = GeometryUtils.faceScale(lm);
        double ci = GeometryUtils.distance(lm.get(52), lm.get(159)) / e;
        double cd = GeometryUtils.distance(lm.get(282), lm.get(386)) / e;
        double cen = GeometryUtils.distance(lm.get(55), lm.get(285)) / e;
        double biY = lm.get(55).y() - lm.get(9).y();
        double bdY = lm.get(285).y() - lm.get(9).y();
        double gap = Math.abs(lm.get(55).x() - lm.get(285).x());

        return ci > cal.threshold("ci")
                || cd > cal.threshold("cd")
                || cen < cal.threshold("cen_lo")
                || biY > cal.threshold("bi_y_lo")
                || bdY > cal.threshold("bd_y_lo")
                || gap < cal.threshold("gap_lo");
    }

    /** A finger touching the mouth (index or middle tip close to mouth-top). */
    public static boolean detectFingerOnMouth(List<Hand> hands, List<NormalizedLandmark> faceLm) {
        NormalizedLandmark mouth = faceLm.get(13);
        for (Hand hand : hands) {
            List<NormalizedLandmark> lm = hand.landmarks;
            if (GeometryUtils.distance(lm.get(8), mouth) < 0.09
                    || GeometryUtils.distance(lm.get(12), mouth) < 0.09) {
                return true;
            }
        }
        return false;
    }

    /** Index + middle extended, others folded (the "rat" gesture). */
    public static boolean detectRat(int[] fingerState) {
        return Arrays.equals(fingerState, new int[]{0, 1, 1, 0, 0});
    }

    /** Both hands raised above the nose. */
    public static boolean detectSonic(List<Hand> hands, List<NormalizedLandmark> faceLm) {
        if (hands.size() != 2) {
            return false;
        }
        double noseY = faceLm.get(1).y();
        for (Hand hand : hands) {
            if (!(hand.landmarks.get(9).y() < noseY)) {
                return false;
            }
        }
        return true;
    }

    /** Both hands open, palms framing the face on either side. */
    public static boolean detectFaceFrame(List<Hand> hands) {
        if (hands.size() != 2) {
            return false;
        }
        for (Hand hand : hands) {
            int[] f = hand.fingerState;
            int[] fingersExceptThumb = Arrays.copyOfRange(f, 1, 5);
            if (!Arrays.equals(fingersExceptThumb, new int[]{1, 1, 1, 1})
                    || hand.landmarks.get(0).y() < 0.50) {
                return false;
            }
        }
        double x0 = hands.get(0).landmarks.get(0).x();
        double x1 = hands.get(1).landmarks.get(0).x();
        return Math.abs(x0 - x1) >= 0.20;
    }
}
