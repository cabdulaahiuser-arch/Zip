package com.gesturememe.app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.SystemClock;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mediapipe.framework.image.BitmapImageBuilder;
import com.google.mediapipe.framework.image.MPImage;
import com.google.mediapipe.tasks.components.containers.Category;
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark;
import com.google.mediapipe.tasks.core.BaseOptions;
import com.google.mediapipe.tasks.core.Delegate;
import com.google.mediapipe.tasks.vision.core.RunningMode;
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker;
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult;
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker;
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Direct port of the Python script's main() loop: opens the camera, runs
 * face + hand landmark detection on every frame, calibrates a neutral-face
 * baseline, evaluates all gesture detectors, applies majority-vote
 * smoothing, and shows the matching meme.
 *
 * Model files required in assets/: face_landmarker.task, hand_landmarker.task
 * (download from Google's MediaPipe model zoo - see README).
 */
public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final int MIN_VOTES = 6;
    private static final int VOTE_BUFFER_SIZE = 10;

    private PreviewView previewView;
    private OverlayView overlayView;
    private ImageView memeImageView;
    private TextView memeLabel;

    private ExecutorService cameraExecutor;
    private FaceLandmarker faceLandmarker;
    private HandLandmarker handLandmarker;

    private final Calibrator calibrator = new Calibrator();
    private final VoteBuffer voteBuffer = new VoteBuffer(VOTE_BUFFER_SIZE, MIN_VOTES);
    private String stableDetection = null;

    // Latest results from each landmarker, combined once both arrive for a frame.
    private volatile FaceLandmarkerResult latestFaceResult = null;
    private volatile HandLandmarkerResult latestHandResult = null;
    private volatile int frameWidth = 640;
    private volatile int frameHeight = 480;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        previewView = findViewById(R.id.previewView);
        overlayView = findViewById(R.id.overlayView);
        memeImageView = findViewById(R.id.memeImageView);
        memeLabel = findViewById(R.id.memeLabel);

        cameraExecutor = Executors.newSingleThreadExecutor();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            initLandmarkersAndStartCamera();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                initLandmarkersAndStartCamera();
            } else {
                Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }

    // ---------------------------------------------------------------------
    // MediaPipe setup
    // ---------------------------------------------------------------------

    private void initLandmarkersAndStartCamera() {
        try {
            setupFaceLandmarker();
            setupHandLandmarker();
        } catch (Exception e) {
            Toast.makeText(this, "Error inicializando MediaPipe: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
            return;
        }
        startCamera();
    }

    private void setupFaceLandmarker() {
        BaseOptions baseOptions = BaseOptions.builder()
                .setDelegate(Delegate.CPU)
                .setModelAssetPath("face_landmarker.task")
                .build();

        FaceLandmarker.FaceLandmarkerOptions options = FaceLandmarker.FaceLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumFaces(1)
                .setMinFaceDetectionConfidence(0.7f)
                .setMinTrackingConfidence(0.7f)
                .setMinFacePresenceConfidence(0.7f)
                .setOutputFaceBlendshapes(false)
                .setResultListener(this::onFaceResult)
                .setErrorListener(this::onLandmarkerError)
                .build();

        faceLandmarker = FaceLandmarker.createFromOptions(this, options);
    }

    private void setupHandLandmarker() {
        BaseOptions baseOptions = BaseOptions.builder()
                .setDelegate(Delegate.CPU)
                .setModelAssetPath("hand_landmarker.task")
                .build();

        HandLandmarker.HandLandmarkerOptions options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(2)
                .setMinHandDetectionConfidence(0.7f)
                .setMinTrackingConfidence(0.7f)
                .setMinHandPresenceConfidence(0.7f)
                .setResultListener(this::onHandResult)
                .setErrorListener(this::onLandmarkerError)
                .build();

        handLandmarker = HandLandmarker.createFromOptions(this, options);
    }

    private void onLandmarkerError(RuntimeException error) {
        runOnUiThread(() ->
                Toast.makeText(this, "Error de deteccion: " + error.getMessage(), Toast.LENGTH_SHORT).show());
    }

    // ---------------------------------------------------------------------
    // Camera (CameraX), equivalent of cv2.VideoCapture + the capture loop
    // ---------------------------------------------------------------------

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture =
                ProcessCameraProvider.getInstance(this);

        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();
                bindCameraUseCases(cameraProvider);
            } catch (ExecutionException | InterruptedException e) {
                Toast.makeText(this, "Error no se pudo abrir la camara", Toast.LENGTH_LONG).show();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void bindCameraUseCases(ProcessCameraProvider cameraProvider) {
        Preview preview = new Preview.Builder().build();
        preview.setSurfaceProvider(previewView.getSurfaceProvider());

        ImageAnalysis imageAnalysis = new ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build();
        imageAnalysis.setAnalyzer(cameraExecutor, this::analyzeFrame);

        CameraSelector cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA;

        cameraProvider.unbindAll();
        cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalysis);
    }

    /** Runs on the camera executor thread for every captured frame. */
    private void analyzeFrame(@NonNull ImageProxy imageProxy) {
        try {
            Bitmap bitmap = imageProxyToBitmap(imageProxy);
            frameWidth = bitmap.getWidth();
            frameHeight = bitmap.getHeight();

            MPImage mpImage = new BitmapImageBuilder(bitmap).build();
            long frameTime = SystemClock.uptimeMillis();

            faceLandmarker.detectAsync(mpImage, frameTime);
            handLandmarker.detectAsync(mpImage, frameTime);
        } finally {
            imageProxy.close();
        }
    }

    /** Converts an ImageProxy (YUV/JPEG) to an upright RGB Bitmap, applying sensor rotation. */
    private Bitmap imageProxyToBitmap(ImageProxy imageProxy) {
        Bitmap bitmap = ImageProxyUtils.toBitmap(imageProxy);
        int rotation = imageProxy.getImageInfo().getRotationDegrees();
        if (rotation != 0) {
            Matrix matrix = new Matrix();
            matrix.postRotate(rotation);
            bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        }
        return bitmap;
    }

    // ---------------------------------------------------------------------
    // Result callbacks - fired asynchronously by MediaPipe (LIVE_STREAM mode)
    // ---------------------------------------------------------------------

    private void onFaceResult(FaceLandmarkerResult result, MPImage image) {
        latestFaceResult = result;
        processCombinedResult();
    }

    private void onHandResult(HandLandmarkerResult result, MPImage image) {
        latestHandResult = result;
        processCombinedResult();
    }

    /**
     * Combines the latest face + hand results (each landmarker runs and
     * reports asynchronously, so we simply react each time either updates,
     * mirroring the per-frame nature of the Python `while True` loop).
     */
    private void processCombinedResult() {
        FaceLandmarkerResult faceResult = latestFaceResult;
        HandLandmarkerResult handResult = latestHandResult;

        List<NormalizedLandmark> faceLm = null;
        if (faceResult != null && !faceResult.faceLandmarks().isEmpty()) {
            faceLm = faceResult.faceLandmarks().get(0);
        }

        List<Hand> hands = new ArrayList<>();
        if (handResult != null && !handResult.landmarks().isEmpty()) {
            List<List<NormalizedLandmark>> allLandmarks = handResult.landmarks();
            List<List<Category>> allHandedness = handResult.handedness();
            for (int i = 0; i < allLandmarks.size(); i++) {
                List<NormalizedLandmark> lm = allLandmarks.get(i);
                boolean isLeft = "Left".equals(allHandedness.get(i).get(0).categoryName());
                int[] fingerState = GeometryUtils.fingerState(lm, isLeft);
                hands.add(new Hand(lm, fingerState, isLeft));
            }
        }

        if (!calibrator.isDone()) {
            if (faceLm != null) {
                calibrator.feed(faceLm);
            }
            runOnUiThread(() -> {
                overlayView.setSourceSize(frameWidth, frameHeight);
                overlayView.updateState(null, new ArrayList<>(), calibrator, true);
            });
            return;
        }

        String detected = detectGesture(faceLm, hands);
        stableDetection = voteBuffer.addAndGetStable(detected, stableDetection);

        List<NormalizedLandmark> finalFaceLm = faceLm;
        runOnUiThread(() -> {
            overlayView.setSourceSize(frameWidth, frameHeight);
            overlayView.updateState(finalFaceLm, hands, calibrator, false);
            updateMemeDisplay(stableDetection);
        });
    }

    /** Evaluates all gesture detectors in the same priority order as the Python script. */
    private String detectGesture(List<NormalizedLandmark> faceLm, List<Hand> hands) {
        if (faceLm != null && hands.size() == 2 && GestureDetector.detectSonic(hands, faceLm)) {
            return "sonic";
        }
        if (hands.size() == 2 && GestureDetector.detectFaceFrame(hands)) {
            return "cara";
        }
        if (faceLm != null && !hands.isEmpty() && GestureDetector.detectFingerOnMouth(hands, faceLm)) {
            return "cristiano";
        }
        if (faceLm != null && GestureDetector.detectTongue(faceLm, calibrator)) {
            return "gato";
        }
        if (faceLm != null && GestureDetector.detectBrow(faceLm, calibrator)) {
            return "perro";
        }
        if (hands.size() == 1 && GestureDetector.detectRat(hands.get(0).fingerState)) {
            return "rata";
        }
        return null;
    }

    private void updateMemeDisplay(String detection) {
        if (detection == null) {
            memeImageView.setImageDrawable(null);
            memeLabel.setText(R.string.label_neutral);
            return;
        }
        int resId;
        switch (detection) {
            case "perro":
                resId = R.drawable.meme_perro;
                break;
            case "gato":
                resId = R.drawable.meme_gato;
                break;
            case "cristiano":
                resId = R.drawable.meme_cristiano;
                break;
            case "cara":
                resId = R.drawable.meme_cara;
                break;
            case "sonic":
                resId = R.drawable.meme_sonic;
                break;
            case "rata":
                resId = R.drawable.meme_rata;
                break;
            default:
                resId = 0;
        }
        if (resId != 0) {
            memeImageView.setImageResource(resId);
            memeLabel.setText(detection);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (cameraExecutor != null) {
            cameraExecutor.shutdown();
        }
        if (faceLandmarker != null) {
            faceLandmarker.close();
        }
        if (handLandmarker != null) {
            handLandmarker.close();
        }
    }
}
