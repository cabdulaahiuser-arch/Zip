package com.gesturememe.app;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.graphics.YuvImage;

import androidx.camera.core.ImageProxy;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

/**
 * Converts a CameraX ImageProxy (YUV_420_888, the standard ImageAnalysis
 * format) into an RGB Bitmap that MediaPipe's BitmapImageBuilder can consume.
 * There is no direct YUV_420_888 -> Bitmap API on Android, so this goes
 * through NV21 + YuvImage + JPEG, which is the standard, dependency-free
 * approach.
 */
public final class ImageProxyUtils {

    private ImageProxyUtils() {
    }

    public static Bitmap toBitmap(ImageProxy image) {
        byte[] nv21 = yuv420ToNv21(image);
        YuvImage yuvImage = new YuvImage(nv21, ImageFormat.NV21,
                image.getWidth(), image.getHeight(), null);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        yuvImage.compressToJpeg(new Rect(0, 0, image.getWidth(), image.getHeight()), 90, out);
        byte[] jpegBytes = out.toByteArray();

        return BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.length);
    }

    private static byte[] yuv420ToNv21(ImageProxy image) {
        ImageProxy.PlaneProxy yPlane = image.getPlanes()[0];
        ImageProxy.PlaneProxy uPlane = image.getPlanes()[1];
        ImageProxy.PlaneProxy vPlane = image.getPlanes()[2];

        ByteBuffer yBuffer = yPlane.getBuffer();
        ByteBuffer uBuffer = uPlane.getBuffer();
        ByteBuffer vBuffer = vPlane.getBuffer();

        int ySize = yBuffer.remaining();
        int width = image.getWidth();
        int height = image.getHeight();
        byte[] nv21 = new byte[width * height * 3 / 2];

        // Y plane: copy row by row to respect rowStride vs width.
        int yRowStride = yPlane.getRowStride();
        int pos = 0;
        if (yRowStride == width) {
            yBuffer.get(nv21, 0, ySize);
            pos = ySize;
        } else {
            byte[] row = new byte[yRowStride];
            for (int r = 0; r < height; r++) {
                yBuffer.get(row, 0, Math.min(yRowStride, yBuffer.remaining()));
                System.arraycopy(row, 0, nv21, pos, width);
                pos += width;
            }
        }

        // VU interleaved plane for NV21. U and V planes share pixel stride
        // in YUV_420_888; interleave V then U per the NV21 layout.
        int uvRowStride = uPlane.getRowStride();
        int uvPixelStride = uPlane.getPixelStride();
        int chromaHeight = height / 2;
        int chromaWidth = width / 2;

        int uvPos = pos;
        for (int r = 0; r < chromaHeight; r++) {
            int rowStart = r * uvRowStride;
            for (int c = 0; c < chromaWidth; c++) {
                int idx = rowStart + c * uvPixelStride;
                byte vByte = vBuffer.get(idx);
                byte uByte = uBuffer.get(idx);
                nv21[uvPos++] = vByte;
                nv21[uvPos++] = uByte;
            }
        }

        return nv21;
    }
}
