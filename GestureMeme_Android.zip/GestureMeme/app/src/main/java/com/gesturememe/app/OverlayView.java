package com.gesturememe.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark;

import java.util.ArrayList;
import java.util.List;

/**
 * Draws the minimal face mesh, hand skeleton, calibration progress bar and
 * text HUD on top of the camera preview. This replaces the Python script's
 * OpenCV drawing calls (draw_face_minimal, draw_hand_minimal, hud, and the
 * calibration screen inside main()).
 */
public class OverlayView extends View {

    private static final int COL_BASE = Color.rgb(140, 200, 140);
    private static final int COL_ACT = Color.rgb(80, 240, 80);

    private final Paint linePaint = new Paint();
    private final Paint dotPaint = new Paint();
    private final Paint textPaint = new Paint();
    private final Paint bgPaint = new Paint();
    private final Paint barTrackPaint = new Paint();
    private final Paint barFillPaint = new Paint();
    private final Paint barBorderPaint = new Paint();

    // Live state pushed in from MainActivity on every processed frame.
    private List<NormalizedLandmark> faceLandmarks = null;
    private final List<Hand> hands = new ArrayList<>();
    private Calibrator calibrator = null;
    private boolean calibrating = true;
    private double calibrationProgress = 0.0;

    // Source image size (the analyzer's frame), used to map normalized -> view pixels.
    private int sourceWidth = 1;
    private int sourceHeight = 1;
    private boolean mirror = true;

    public OverlayView(Context context, AttributeSet attrs) {
        super(context, attrs);
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(3f);
        linePaint.setAntiAlias(true);

        dotPaint.setStyle(Paint.Style.FILL);
        dotPaint.setAntiAlias(true);

        textPaint.setTextSize(36f);
        textPaint.setAntiAlias(true);
        textPaint.setColor(Color.rgb(200, 200, 200));

        bgPaint.setColor(Color.argb(140, 0, 0, 0));

        barTrackPaint.setColor(Color.rgb(40, 40, 40));
        barFillPaint.setColor(Color.rgb(80, 220, 80));
        barBorderPaint.setStyle(Paint.Style.STROKE);
        barBorderPaint.setStrokeWidth(2f);
        barBorderPaint.setColor(Color.rgb(120, 120, 120));
    }

    public void setSourceSize(int width, int height) {
        this.sourceWidth = Math.max(width, 1);
        this.sourceHeight = Math.max(height, 1);
    }

    public void setMirror(boolean mirror) {
        this.mirror = mirror;
    }

    /** Called every analyzed frame with the latest detection state. */
    public void updateState(List<NormalizedLandmark> faceLandmarks,
                             List<Hand> hands,
                             Calibrator calibrator,
                             boolean calibrating) {
        this.faceLandmarks = faceLandmarks;
        this.hands.clear();
        this.hands.addAll(hands);
        this.calibrator = calibrator;
        this.calibrating = calibrating;
        this.calibrationProgress = calibrator == null ? 0.0 : calibrator.progress();
        postInvalidateOnAnimation();
    }

    private float mapX(double normX) {
        double x = mirror ? (1.0 - normX) : normX;
        return (float) (x * getWidth());
    }

    private float mapY(double normY) {
        return (float) (normY * getHeight());
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (calibrating) {
            drawCalibrationOverlay(canvas);
            return;
        }

        if (faceLandmarks != null && calibrator != null) {
            drawFace(canvas, faceLandmarks, calibrator);
        }
        for (Hand hand : hands) {
            drawHand(canvas, hand);
        }
        drawHud(canvas);
    }

    private void drawCalibrationOverlay(Canvas canvas) {
        canvas.drawRect(0, 0, getWidth(), getHeight(), bgPaint);

        String msg = getContext().getString(R.string.calibration_hint);
        float textWidth = textPaint.measureText(msg);
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        canvas.drawText(msg, cx - textWidth / 2f, cy - 40, textPaint);

        float barHalf = 280f;
        float top = cy + 10;
        float bottom = cy + 44;
        canvas.drawRect(cx - barHalf, top, cx + barHalf, bottom, barTrackPaint);
        float fillWidth = (float) (barHalf * 2 * calibrationProgress);
        canvas.drawRect(cx - barHalf, top, cx - barHalf + fillWidth, bottom, barFillPaint);
        canvas.drawRect(cx - barHalf, top, cx + barHalf, bottom, barBorderPaint);

        String pct = Math.round(calibrationProgress * 100) + "%";
        float pctWidth = textPaint.measureText(pct);
        canvas.drawText(pct, cx - pctWidth / 2f, bottom + 40, textPaint);
    }

    private void drawFace(Canvas canvas, List<NormalizedLandmark> lm, Calibrator cal) {
        double e = GeometryUtils.faceScale(lm);
        double ci = GeometryUtils.distance(lm.get(52), lm.get(159)) / e;
        double cd = GeometryUtils.distance(lm.get(282), lm.get(386)) / e;
        double cen = GeometryUtils.distance(lm.get(55), lm.get(285)) / e;
        boolean bocaActiva = GeometryUtils.distance(lm.get(13), lm.get(14)) / e > cal.threshold("lap")
                && GeometryUtils.distance(lm.get(17), lm.get(152)) / e < cal.threshold("llb");
        boolean cejaActiva = ci > cal.threshold("ci") || cd > cal.threshold("cd") || cen < cal.threshold("cen_lo");

        int colCeja = cejaActiva ? COL_ACT : COL_BASE;
        int colBoca = bocaActiva ? COL_ACT : COL_BASE;

        drawPath(canvas, lm, LandmarkPaths.FACE_OVAL, COL_BASE);
        drawPath(canvas, lm, LandmarkPaths.EYE_L, COL_BASE);
        drawPath(canvas, lm, LandmarkPaths.EYE_R, COL_BASE);
        drawPath(canvas, lm, LandmarkPaths.BROW_L, colCeja);
        drawPath(canvas, lm, LandmarkPaths.BROW_R, colCeja);
        drawPath(canvas, lm, LandmarkPaths.NOSE, COL_BASE);
        drawPath(canvas, lm, LandmarkPaths.LIPS_OUT, colBoca);
        drawPath(canvas, lm, LandmarkPaths.LIPS_IN, colBoca);
    }

    private void drawPath(Canvas canvas, List<NormalizedLandmark> lm, int[] indices, int color) {
        linePaint.setColor(color);
        dotPaint.setColor(color);
        float prevX = 0, prevY = 0;
        boolean hasPrev = false;
        for (int idx : indices) {
            NormalizedLandmark pt = lm.get(idx);
            float x = mapX(pt.x());
            float y = mapY(pt.y());
            if (hasPrev) {
                canvas.drawLine(prevX, prevY, x, y, linePaint);
            }
            canvas.drawCircle(x, y, 2.5f, dotPaint);
            prevX = x;
            prevY = y;
            hasPrev = true;
        }
    }

    private void drawHand(Canvas canvas, Hand hand) {
        linePaint.setColor(COL_BASE);
        dotPaint.setColor(COL_BASE);
        List<NormalizedLandmark> lm = hand.landmarks;

        for (int[] conn : LandmarkPaths.HAND_CONNECTIONS) {
            NormalizedLandmark a = lm.get(conn[0]);
            NormalizedLandmark b = lm.get(conn[1]);
            canvas.drawLine(mapX(a.x()), mapY(a.y()), mapX(b.x()), mapY(b.y()), linePaint);
        }
        for (int i = 0; i < 21; i++) {
            NormalizedLandmark pt = lm.get(i);
            canvas.drawCircle(mapX(pt.x()), mapY(pt.y()), 4f, dotPaint);
        }

        int[] tips = {4, 8, 12, 16, 20};
        dotPaint.setColor(COL_ACT);
        for (int i = 0; i < tips.length; i++) {
            if (hand.fingerState[i] == 1) {
                NormalizedLandmark pt = lm.get(tips[i]);
                canvas.drawCircle(mapX(pt.x()), mapY(pt.y()), 6f, dotPaint);
            }
        }
    }

    private void drawHud(Canvas canvas) {
        Paint smallText = new Paint(textPaint);
        smallText.setTextSize(28f);
        smallText.setColor(Color.rgb(160, 160, 160));

        float y = 40;
        for (Hand hand : hands) {
            StringBuilder sb = new StringBuilder(hand.sideLabel()).append(": [");
            for (int i = 0; i < hand.fingerState.length; i++) {
                if (i > 0) sb.append(", ");
                sb.append(hand.fingerState[i]);
            }
            sb.append("]");
            canvas.drawRect(6, y - 22, 6 + smallText.measureText(sb.toString()) + 12, y + 8, bgPaint);
            canvas.drawText(sb.toString(), 12, y, smallText);
            y += 34;
        }
    }
}
