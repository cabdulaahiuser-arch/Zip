# Gesture Meme (Android)

Native Android (Java + XML) port of the original Python/OpenCV/MediaPipe
desktop app. Detects facial and hand gestures in real time from the front
camera and shows the matching meme image, using MediaPipe Tasks
(FaceLandmarker + HandLandmarker) and CameraX.

## Tech stack

- **Java** (no Kotlin)
- **CameraX** (`camera-core`, `camera-camera2`, `camera-lifecycle`, `camera-view`)
- **MediaPipe Tasks Vision** (`com.google.mediapipe:tasks-vision:0.10.14`)
- Min SDK 24, target/compile SDK 34

## Required setup: model files

MediaPipe Tasks needs two `.task` model bundles that are too large to embed
directly. Download them and place them in `app/src/main/assets/`:

1. `face_landmarker.task`
   https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task
2. `hand_landmarker.task`
   https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task

Final layout:

    app/src/main/assets/face_landmarker.task
    app/src/main/assets/hand_landmarker.task

The app will crash on launch with a MediaPipe initialization error if these
files are missing.

## Required setup: meme images

`res/drawable/meme_*.xml` are placeholder vector drawables (a simple green
smiley on dark background) so the project compiles and runs out of the box.
Replace them with your real meme images:

1. Convert your meme images (`perro.jpeg`, `gato1.png`, `cristiano.png`,
   `cara.jpeg`, `Sonic.jpeg`, `rata.jpeg`) to PNG/JPG.
2. Delete the matching placeholder `.xml` file in `res/drawable/`.
3. Add your image with the **same base name** (e.g. `meme_perro.png`).
4. Android resource names must be lowercase with underscores only, which is
   why the names differ slightly from the Python filenames:

   | Python file      | Android resource name |
   |-------------------|------------------------|
   | `perro.jpeg`      | `meme_perro`           |
   | `gato1.png`       | `meme_gato`            |
   | `cristiano.png`   | `meme_cristiano`       |
   | `cara.jpeg`       | `meme_cara`            |
   | `Sonic.jpeg`      | `meme_sonic`           |
   | `rata.jpeg`       | `meme_rata`            |

## Gestures detected

Same logic and thresholds as the Python version, evaluated in this priority
order (first match wins), each frame:

| Gesture (priority order)                 | Meme resource     |
|-------------------------------------------|--------------------|
| Both hands above the nose                 | `meme_sonic`       |
| Both hands open, framing the face         | `meme_cara`        |
| A finger touching the mouth               | `meme_cristiano`   |
| Tongue out                                | `meme_gato`        |
| Eyebrows raised or furrowed               | `meme_perro`       |
| Index + middle fingers extended (one hand)| `meme_rata`        |

## How it works / project structure

    app/src/main/java/com/gesturememe/app/
    ├── MainActivity.java       - CameraX + MediaPipe wiring; port of Python main()
    ├── GeometryUtils.java      - distance/scale/finger-state math (d, esc, dedos_estado)
    ├── Calibrator.java         - neutral-face baseline calibration (Cal class)
    ├── GestureDetector.java    - all det_* gesture functions
    ├── LandmarkPaths.java      - face/hand landmark index constants for drawing
    ├── Hand.java               - holder for one hand's landmarks/side/finger-state
    ├── VoteBuffer.java         - majority-vote smoothing (deque + Counter equivalent)
    ├── OverlayView.java        - draws face mesh, hand skeleton, HUD, calibration bar
    └── ImageProxyUtils.java    - YUV_420_888 ImageProxy -> Bitmap conversion

    app/src/main/res/
    ├── layout/activity_main.xml   - camera preview (top) + meme panel (bottom)
    ├── drawable/meme_*.xml        - placeholder meme images (replace these)
    └── values/                    - strings, colors, theme

## Behavioral differences from the Python version (unavoidable on mobile)

- **Camera**: uses the **front** camera by default (typical for a gesture app
  held by the user), whereas the Python script opens whatever webcam index 0/1
  resolves to. Change `CameraSelector.DEFAULT_FRONT_CAMERA` to
  `DEFAULT_BACK_CAMERA` in `MainActivity.bindCameraUseCases()` if you want the
  rear camera instead.
- **Two windows**: OpenCV's two `cv2.imshow` windows become one screen split
  into a top half (camera + overlay) and bottom half (meme), since Android
  apps are single-window. The visual layout is preserved.
- **Async landmark results**: MediaPipe Tasks Android delivers face and hand
  results via asynchronous callbacks (`LIVE_STREAM` mode) rather than the
  blocking calls Python uses; the app simply reacts each time either result
  updates, which is visually equivalent at typical frame rates.
- **Calibration UI**: the neutral-face calibration step is preserved
  identically (mira al frente, progress bar, same 45-frame buffer and same
  median/std threshold formulas), just drawn with Android `Canvas` instead of
  OpenCV.

## Build

Open the project root in Android Studio (Hedgehog or newer), let Gradle
sync, add the two `.task` model files as described above, then Run on a
physical device (the emulator's virtual camera is usually too poor for
reliable face/hand tracking).

## Permissions

The app requests `CAMERA` permission at runtime on first launch. If denied,
the app shows a message and closes, matching the Python script's behavior of
exiting if the camera can't be opened.
